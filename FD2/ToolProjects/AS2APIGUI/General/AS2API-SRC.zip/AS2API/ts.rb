require 'test/unit'
require 'tc_actionscript_lexer.rb'
require 'tc_actionscript_parser.rb'
require 'tc_doc_comment.rb'
