#!/usr/bin/ruby -w

require 'ui/cli'
